package data.campaign.econ;

public class anvil_industries {
    public static final String anvil_lab = "anvil_lab";
}
