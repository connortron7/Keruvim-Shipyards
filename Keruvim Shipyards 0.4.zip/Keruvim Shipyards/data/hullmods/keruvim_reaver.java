package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

import java.util.HashSet;
import java.util.Set;

public class keruvim_reaver extends BaseHullMod {
	private final float FluxUsage = 0.9F;
	private static final Set<String> BLOCKED_HULLMODS = new HashSet(7);
	public keruvim_reaver() {
	}

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getBallisticWeaponFluxCostMod().modifyMult(id, 0.9F);
	}

	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		for (String tmp : BLOCKED_HULLMODS) {
			if (ship.getVariant().getHullMods().contains(tmp))
				ship.getVariant().removeMod(tmp);
		}
	}

	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 1) {
			return Math.round(19.999998F) + "%";
		} else if (index == 0) {
			return Math.round(10.000002F) + "%";
		} else {
			return index == 2 ? Math.round(10.000002F) + "%" : null;
		}
	}

	static {
		BLOCKED_HULLMODS.add("safetyoverrides");
	}
}