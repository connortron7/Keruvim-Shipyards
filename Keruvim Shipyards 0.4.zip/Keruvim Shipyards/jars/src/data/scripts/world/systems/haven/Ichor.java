package data.scripts.world.systems.haven;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;

public class Ichor {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Ichor");

		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		PlanetAPI ichor_star = system.initStar("Ichor", // unique id for this star
				"star_red_dwarf", // Star type. Vanilla star types can be found in starsector-core/data/campaign/procgen/star_gen_data.csv and starsector-core/data/config/planets.json
				700f, 		  // radius (in pixels at default zoom)
				350); // corona radius, from star edge

		system.setLightColor(new Color(205,25,64)); // light color in entire system, affects all entities

		PlanetAPI tomb = system.addPlanet("anvil_heritage", ichor_star, "Heritage", "lava_minor", 90, 170, 6500, 225);
		tomb.setCustomDescriptionId("anvil_heritage");



		// Mausoleum Inner Jumppoint
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("Ichor_jump", "Ichor Inner Jump-point");
		jumpPoint2.setCircularOrbit( system.getEntityById("Ichor"),30, 2200, 225);
		system.addEntity(jumpPoint2);




		PlanetAPI grave = system.addPlanet("anvil_deluge", ichor_star, "deluge", "jungle", 180, 120, 8300, 400);
		grave.setCustomDescriptionId("anvil_deluge");
		// Morn accretion cloud



		SectorEntityToken station1 = system.addCustomEntity("anvil_exile", "Exile Mining Station", "station_side00", "reaver");
		station1.setCustomDescriptionId("anvil_exile");
		station1.setInteractionImage("illustrations", "orbital");
		station1.setCircularOrbitWithSpin(ichor_star, 180+60, 4300, 400, -1f, -3f);


		SectorEntityToken mausoleum_loc1 = system.addCustomEntity(null, null, "sensor_array_makeshift", "reaver");
		mausoleum_loc1.setCircularOrbitPointingDown(ichor_star, 60, 2870, 90);

		SectorEntityToken mausoleum_loc2 = system.addCustomEntity(null, null, "comm_relay_makeshift", "reaver");
		mausoleum_loc2.setCircularOrbitPointingDown(ichor_star,150, 5200, 225);


		system.addAsteroidBelt(ichor_star, // Variable stocking the entity you want the asteroid belt to encircle
				90, // Number of asteroids in the belt
				3750, // Diameter (I think) of the belt, in pixels (I guess, again)
				500, // How thicc the belt is. The asteroids will spread more the higher the value
				100, // Minimum of days required for the asteroid belt to do an entire cycle
				120); // Maximum days the belt will take to do a cycle
		// Adding a ring band to make the belt feel less empty

		system.addAsteroidBelt(ichor_star, // Variable stocking the entity you want the asteroid belt to encircle
				120, // Number of asteroids in the belt
				4300, // Diameter (I think) of the belt, in pixels (I guess, again)
				500, // How thicc the belt is. The asteroids will spread more the higher the value
				290, // Minimum of days required for the asteroid belt to do an entire cycle
				320); // Maximum days the belt will take to do a cycle
		// Adding a ring band to make the belt feel less empty

		system.addAsteroidBelt(ichor_star, // Variable stocking the entity you want the asteroid belt to encircle
				300, // Number of asteroids in the belt
				6500, // Diameter (I think) of the belt, in pixels (I guess, again)
				500, // How thicc the belt is. The asteroids will spread more the higher the value
				160, // Minimum of days required for the asteroid belt to do an entire cycle
				300); // Maximum days the belt will take to do a cycle
		// Adding a ring band to make the belt feel less empty


		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, ichor_star, StarAge.AVERAGE,
				2, 4, // min/max entities to add
				12000, // radius to start adding at
				5, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true); // whether to use custom or system-name based names

		system.autogenerateHyperspaceJumpPoints(true, true);

		//Getting rid of some hyperspace nebula, just in case
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}

}
